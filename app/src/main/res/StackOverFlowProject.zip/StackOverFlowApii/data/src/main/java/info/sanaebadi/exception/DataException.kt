package info.sanaebadi.exception

class DataException(val code: String, override val message: String) : Exception()
