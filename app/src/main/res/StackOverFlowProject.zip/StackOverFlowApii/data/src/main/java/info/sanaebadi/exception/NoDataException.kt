package info.sanaebadi.exception

class NoDataException : Exception()
