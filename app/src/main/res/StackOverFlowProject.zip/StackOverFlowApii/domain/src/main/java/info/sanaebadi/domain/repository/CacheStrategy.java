package info.sanaebadi.domain.repository;

public enum CacheStrategy {
    ONLINE_FIRST,
    CACHE_FIRST
}
