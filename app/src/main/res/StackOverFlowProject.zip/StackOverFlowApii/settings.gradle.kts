include(":domain")
include(":data")
include (":app")
rootProject.name = "StackOverFlowProject"